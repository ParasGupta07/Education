import React from "react";
import "./BackgroundGrid.css";

const BackgroundGrid = () => {
  return <div className="background-grid"></div>;
};

export default BackgroundGrid;
