import React from "react";
import "./CourseCard.css";

export default function CourseCard() {
  return (
    <div className="course-card-container">
      <div className="course-card-border"></div>

      <div className="course-card-title-container">
        <span className="course-card-title">Keys to Success</span>
        <p className="course-card-paragraph">
          Best way to be success in your life.
        </p>
      </div>

      <hr className="course-card-line" />

      <ul className="course-card-list">
        <li className="course-card-list-item">
          <span className="course-card-check">
            <svg
              className="course-card-check-svg"
              fill="currentColor"
              viewBox="0 0 16 16"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                clipRule="evenodd"
                fillRule="evenodd"
                d="M12.416 3.376a.75.75 0 0 1 .208 1.04l-5 7.5a.75.75 0 0 1-1.154.114l-3-3a.75.75 0 0 1 1.06-1.06l2.353 2.353 4.493-6.74a.75.75 0 0 1 1.04-.207Z"
              />
            </svg>
          </span>
          <span className="course-card-list-text">Set Clear Goals</span>
        </li>

        <li className="course-card-list-item">
          <span className="course-card-check">
            <svg
              className="course-card-check-svg"
              fill="currentColor"
              viewBox="0 0 16 16"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                clipRule="evenodd"
                fillRule="evenodd"
                d="M12.416 3.376a.75.75 0 0 1 .208 1.04l-5 7.5a.75.75 0 0 1-1.154.114l-3-3a.75.75 0 0 1 1.06-1.06l2.353 2.353 4.493-6.74a.75.75 0 0 1 1.04-.207Z"
              />
            </svg>
          </span>
          <span className="course-card-list-text">Stay Organized</span>
        </li>

        <li className="course-card-list-item">
          <span className="course-card-check">
            <svg
              className="course-card-check-svg"
              fill="currentColor"
              viewBox="0 0 16 16"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                clipRule="evenodd"
                fillRule="evenodd"
                d="M12.416 3.376a.75.75 0 0 1 .208 1.04l-5 7.5a.75.75 0 0 1-1.154.114l-3-3a.75.75 0 0 1 1.06-1.06l2.353 2.353 4.493-6.74a.75.75 0 0 1 1.04-.207Z"
              />
            </svg>
          </span>
          <span className="course-card-list-text">Continuous Learning</span>
        </li>

        <li className="course-card-list-item">
          <span className="course-card-check">
            <svg
              className="course-card-check-svg"
              fill="currentColor"
              viewBox="0 0 16 16"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                clipRule="evenodd"
                fillRule="evenodd"
                d="M12.416 3.376a.75.75 0 0 1 .208 1.04l-5 7.5a.75.75 0 0 1-1.154.114l-3-3a.75.75 0 0 1 1.06-1.06l2.353 2.353 4.493-6.74a.75.75 0 0 1 1.04-.207Z"
              />
            </svg>
          </span>
          <span className="course-card-list-text">Time Management</span>
        </li>

        <li className="course-card-list-item">
          <span className="course-card-check">
            <svg
              className="course-card-check-svg"
              fill="currentColor"
              viewBox="0 0 16 16"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                clipRule="evenodd"
                fillRule="evenodd"
                d="M12.416 3.376a.75.75 0 0 1 .208 1.04l-5 7.5a.75.75 0 0 1-1.154.114l-3-3a.75.75 0 0 1 1.06-1.06l2.353 2.353 4.493-6.74a.75.75 0 0 1 1.04-.207Z"
              />
            </svg>
          </span>
          <span className="course-card-list-text">
            Maintain a Positive Attitude
          </span>
        </li>
      </ul>

    </div>
  );
}
