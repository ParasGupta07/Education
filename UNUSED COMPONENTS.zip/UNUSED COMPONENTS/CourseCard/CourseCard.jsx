import React from "react";
import "./CourseCard.css";

export default function CourseCard({ title, text, features = [] }) {
  return (
    <div className="course-card-container">
      <div className="course-card">
        <div className="course-card-glass"></div>
        <div className="course-card-content">
          <span className="course-card-title">{title}</span>
          <span className="course-card-text">{text}</span>

          <ul className="course-card-features">
            {features.map((feature, index) => (
              <li key={index}>
                <span className="course-card-icon">
                  <svg height="24" width="24" viewBox="0 0 24 24">
                    <path d="M0 0h24v24H0z" fill="none"></path>
                    <path
                      fill="currentColor"
                      d="M10 15.172l9.192-9.193 1.415 1.414L10 18l-6.364-6.364 1.414-1.414z"
                    ></path>
                  </svg>
                </span>
                {/* Support HTML (like <strong>) inside feature */}
                <span dangerouslySetInnerHTML={{ __html: feature }} />
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
