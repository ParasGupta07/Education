import React from "react";
import CourseCard from "../CourseCard/CourseCard";
import "./Courses.css";
import TilesBackground from "../TilesBackground/TilesBackground";

export default function Courses() {
  const coursesData = [
    {
      category: "RV Go - BUCKET SHELL",
      type: "single",
      courses: [
        {
          title: "Program Details",
          text: "Comprehensive support for school academics and international boards.",
          features: [
            "School Academics (<strong>IB/IGCSE/A Level/ICSE/CBSE/US</strong>)",
            "Foundation For <strong>APs</strong>",
            "Foundation for <strong>SAT</strong> (Free ISEE & PSAT)",
            "<strong>$23 per class</strong> (International Kids)",
            "<strong>Rs. 600 to 1000</strong> per class (CBSE, ICSE)",
            "<strong>Rs 1000 to 1200</strong> per class (IB, IGCSE)",
            "<strong>*Affordable Cost</strong> - please contact",
          ],
        },
      ],
    },
    {
      category: "RV Go - SAT",
      type: "multiple",
      courses: [
        {
          title: "Fast Track Program",
          text: "A quick-paced SAT prep program for ambitious learners.",
          features: [
            "<strong>2 months</strong> program*",
            "Master Classes",
            "Strategy Sessions",
            "Full-length <strong>Mocks</strong>",
            "Remedial sessions",
            "*Conditions apply",
          ],
        },
        {
          title: "Steady Track Program",
          text: "Balanced learning with extended preparation for the SAT.",
          features: [
            "<strong>4 months</strong> program*",
            "Special Sessions",
            "Strategy Sessions",
            "Mocks",
            "Remedial sessions",
            "*Conditions apply",
          ],
        },
        {
          title: "Foundation",
          text: "Strong base-building for SAT with in-depth sessions.",
          features: [
            "<strong>4+ months</strong> program*",
            "Inclusive of <strong>Master classes</strong>, special sessions etc.",
            "Strategy Sessions",
            "Mocks",
            "Remedial sessions",
            "*Affordable Cost - please contact",
          ],
        },
      ],
    },
    {
      category: "RV Go - ACT",
      type: "multiple",
      courses: [
        {
          title: "Fast Track Program",
          text: "Focused ACT preparation designed to maximize quick results.",
          features: [
            "<strong>2 months</strong> program*",
            "Master Classes",
            "Strategy Sessions",
            "Mocks",
            "Remedial sessions",
            "*Conditions apply",
          ],
        },
        {
          title: "Steady Track Program",
          text: "Steady preparation for consistent improvement in ACT scores.",
          features: [
            "<strong>4 months</strong> program*",
            "Special Sessions",
            "Strategy Sessions",
            "Mocks",
            "Remedial sessions",
            "*Conditions apply",
          ],
        },
        {
          title: "Foundation",
          text: "Extended ACT foundation program for thorough preparation.",
          features: [
            "<strong>4+ months</strong> program*",
            "Intensive sessions - Inclusive of <strong>Master classes</strong>, special sessions etc.",
            "Strategy Sessions",
            "Mocks",
            "Remedial sessions",
          ],
        },
      ],
    },
    {
      category: "RV Go - APS",
      type: "single",
      courses: [
        {
          title: "Program Details",
          text: "Personalized one-on-one tutoring for AP subjects.",
          features: [
            "<strong>One on One</strong> tutoring",
            "<strong>Expert </strong>tutors",
            "<strong>Affordable </strong>Cost",
          ],
        },
      ],
    },
  ];

  return (
    <div className="courses-wrapper">
      {/* ✅ Animated Background */}
      <TilesBackground />

      {/* Foreground Content */}
      <div className="courses-section-container">
        {coursesData.map((category, index) => (
          <div
            key={index}
            className={
              category.type === "single"
                ? "courses-category-single"
                : "courses-category-multiple"
            }
          >
            <h2 className="courses-category-title">{category.category}</h2>
            <div
              className={
                category.type === "single"
                  ? "courses-list-single"
                  : "courses-list-multiple"
              }
            >
              {category.courses.map((course, idx) => (
                <CourseCard
                  key={idx}
                  title={course.title}
                  text={course.text}
                  features={course.features}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
