"use client";

import React, { useEffect } from "react";
import * as THREE from "three";
import { TweenMax, Power1, Power3, Sine } from "gsap";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

import "./Float.css";

const Float = () => {
  useEffect(() => {
    let scene, camera, renderer, controls;
    let _group = new THREE.Group();

    const Theme = {
      primary: 0xd7dddd,
      secundary: 0x0000ff,
      danger: 0xff0000,
      darker: 0x101010,
    };

    function init() {
      createWorld();
      createLights();
      createPrimitive();
      animation();
    }

    function createWorld() {
      const container = document.getElementById("Float-canvas-container");
      const _width = window.innerWidth;
      const _height = container.clientHeight;

      scene = new THREE.Scene();
      scene.fog = new THREE.Fog(Theme.primary, 9, 13);

      camera = new THREE.PerspectiveCamera(35, _width / _height, 1, 1000);
      camera.position.set(0, 0, 10);

      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(_width, _height);

      // ✅ Correct usage of OrbitControls
      controls = new OrbitControls(camera, renderer.domElement);
      controls.enableZoom = false;
      controls.update();

      container.appendChild(renderer.domElement);

      window.addEventListener("resize", onWindowResize, false);
    }

    function onWindowResize() {
      const _width = window.innerWidth;
      const _height = window.innerHeight;
      renderer.setSize(_width, _height);
      camera.aspect = _width / _height;
      camera.updateProjectionMatrix();
    }

    function createLights() {
      const hemiLight = new THREE.HemisphereLight(Theme.primary, Theme.darker, 1);
      const dirLight = new THREE.DirectionalLight(0xffffff, 1);
      dirLight.position.set(10, 20, 20);
      dirLight.castShadow = true;

      scene.add(hemiLight);
      scene.add(dirLight);
    }

    function CreateBook() {
      this.mesh = new THREE.Object3D();
      const geo_cover = new THREE.BoxGeometry(2.4, 3, 0.05);
      const lmo_cover = new THREE.BoxGeometry(0.05, 3, 0.59);
      const ppr_cover = new THREE.BoxGeometry(2.3, 2.8, 0.5);

      const mat = new THREE.MeshPhongMaterial({ color: 0x475b47 });
      const mat_paper = new THREE.MeshPhongMaterial({ color: 0xffffff });

      const _cover1 = new THREE.Mesh(geo_cover, mat);
      const _cover2 = new THREE.Mesh(geo_cover, mat);
      const _lomo = new THREE.Mesh(lmo_cover, mat);
      const _paper = new THREE.Mesh(ppr_cover, mat_paper);

      [_cover1, _cover2, _lomo, _paper].forEach((mesh) => {
        mesh.castShadow = true;
        mesh.receiveShadow = true;
      });

      _cover1.position.z = 0.3;
      _cover2.position.z = -0.3;
      _lomo.position.x = 2.4 / 2;

      this.mesh.add(_cover1, _cover2, _lomo, _paper);
    }

    function isTooClose(newObj, others, minDistance = 1.5) {
      const newPos = newObj.position;
      for (let existing of others) {
        const dx = newPos.x - existing.position.x;
        const dy = newPos.y - existing.position.y;
        const dz = newPos.z - existing.position.z;
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < minDistance) return true;
      }
      return false;
    }

    function createPrimitive() {
      const placedBooks = [];
      const a = 2;

      for (let i = 0; i < 12; i++) {
        const _object = new CreateBook();
        const s = 0.1 + Math.random() * 0.4;
        _object.mesh.scale.set(s, s, s);

        let tries = 0;
        do {
          _object.mesh.position.x = (Math.random() - 0.5) * a * 2;
          _object.mesh.position.y = (Math.random() - 0.5) * a * 2;
          _object.mesh.position.z = (Math.random() - 0.5) * a * 2;
          tries++;
        } while (isTooClose(_object.mesh, placedBooks) && tries < 20);

        _object.mesh.rotation.x = Math.random() * 2 * Math.PI;
        _object.mesh.rotation.y = Math.random() * 2 * Math.PI;
        _object.mesh.rotation.z = Math.random() * 2 * Math.PI;

        TweenMax.to(_object.mesh.rotation, 8 + Math.random() * 8, {
          x: (Math.random() - 0.5) * 0.5,
          y: (Math.random() - 0.5) * 0.5,
          z: (Math.random() - 0.5) * 0.5,
          yoyo: true,
          repeat: -1,
          ease: Sine.easeInOut,
          delay: 0.05 * i,
        });

        _group.add(_object.mesh);
        placedBooks.push(_object.mesh);
      }

      scene.add(_group);
    }

    function animation() {
      _group.rotation.x -= 0.003;
      _group.rotation.y -= 0.003;
      _group.rotation.z -= 0.003;
      controls.update();
      requestAnimationFrame(animation);
      renderer.render(scene, camera);
    }

    init();

    return () => {
      window.removeEventListener("resize", onWindowResize);
    };
  }, []);

  return (
    <div className="Float-container">
      <div id="Float-canvas-container" className="Float-right-side"></div>
      <div className="Float-text">Scroll Down to Explore</div>
    </div>
  );
};

export default Float;
