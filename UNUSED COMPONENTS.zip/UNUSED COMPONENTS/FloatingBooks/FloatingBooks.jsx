import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls";
import { TweenMax, Sine } from "gsap";
import "./FloatingBooks.css";

const FloatingBooks = () => {
  const containerRef = useRef(null);

  useEffect(() => {
    let scene, camera, renderer, controls;
    const booksGroup = new THREE.Group();

    const Theme = {
      primary: 0xd7dddd,
      secundary: 0x0000ff,
      danger: 0xff0000,
      darker: 0x101010,
    };

    function init() {
      createWorld();
      createLights();
      createBooks();
      animate();
    }

    function createWorld() {
      const width = window.innerWidth;
      const height = containerRef.current?.clientHeight || window.innerHeight;

      scene = new THREE.Scene();
      scene.fog = new THREE.Fog(Theme.primary, 9, 13);

      camera = new THREE.PerspectiveCamera(35, width / height, 1, 1000);
      camera.position.set(0, 0, 10);

      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;

      controls = new OrbitControls(camera, renderer.domElement);
      controls.enableZoom = false;
      controls.update();

      containerRef.current?.appendChild(renderer.domElement);
      window.addEventListener("resize", onWindowResize);
    }

    function onWindowResize() {
      const width = window.innerWidth;
      const height = containerRef.current?.clientHeight || window.innerHeight;
      if (renderer && camera) {
        renderer.setSize(width, height);
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
      }
    }

    function createLights() {
      const hemiLight = new THREE.HemisphereLight(Theme.primary, Theme.darker, 1);
      const dirLight = new THREE.DirectionalLight(0xffffff, 1);
      dirLight.position.set(10, 20, 20);
      dirLight.castShadow = true;
      dirLight.shadow.mapSize.width = 5000;
      dirLight.shadow.mapSize.height = 5000;

      scene.add(hemiLight, dirLight);
    }

    function CreateBook() {
      this.mesh = new THREE.Object3D();

      const geoCover = new THREE.BoxGeometry(2.4, 3, 0.05);
      const lmoCover = new THREE.BoxGeometry(0.05, 3, 0.59);
      const pprCover = new THREE.BoxGeometry(2.3, 2.8, 0.5);

      const dartmouthGreens = [0x475b47];
      const randomGreen = dartmouthGreens[Math.floor(Math.random() * dartmouthGreens.length)];

      const mat = new THREE.MeshPhongMaterial({ color: randomGreen });
      const matPaper = new THREE.MeshPhongMaterial({ color: 0xffffff });

      const cover1 = new THREE.Mesh(geoCover, mat);
      const cover2 = new THREE.Mesh(geoCover, mat);
      const lomo = new THREE.Mesh(lmoCover, mat);
      const paper = new THREE.Mesh(pprCover, matPaper);

      [cover1, cover2, lomo, paper].forEach(mesh => {
        mesh.castShadow = true;
        mesh.receiveShadow = true;
      });

      cover1.position.z = 0.3;
      cover2.position.z = -0.3;
      lomo.position.x = 2.4 / 2;

      this.mesh.add(cover1, cover2, lomo, paper);
    }

    function isTooClose(newObj, others, minDistance = 1.5) {
      const newPos = newObj.position;
      for (let existing of others) {
        const dx = newPos.x - existing.position.x;
        const dy = newPos.y - existing.position.y;
        const dz = newPos.z - existing.position.z;
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < minDistance) return true;
      }
      return false;
    }

    function createBooks() {
      const placedBooks = [];
      const range = 2;

      for (let i = 0; i < 12; i++) {
        const book = new CreateBook();
        const s = 0.1 + Math.random() * 0.4;
        book.mesh.scale.set(s, s, s);

        let tries = 0;
        do {
          book.mesh.position.x = (Math.random() - 0.5) * range * 2;
          book.mesh.position.y = (Math.random() - 0.5) * range * 2;
          book.mesh.position.z = (Math.random() - 0.5) * range * 2;
          tries++;
        } while (isTooClose(book.mesh, placedBooks) && tries < 20);

        book.mesh.rotation.x = Math.random() * Math.PI * 2;
        book.mesh.rotation.y = Math.random() * Math.PI * 2;
        book.mesh.rotation.z = Math.random() * Math.PI * 2;

        TweenMax.to(book.mesh.rotation, 8 + Math.random() * 8, {
          x: (Math.random() - 0.5) * 0.5,
          y: (Math.random() - 0.5) * 0.5,
          z: (Math.random() - 0.5) * 0.5,
          yoyo: true,
          repeat: -1,
          ease: Sine.easeInOut,
          delay: 0.05 * i,
        });

        booksGroup.add(book.mesh);
        placedBooks.push(book.mesh);
      }

      booksGroup.position.x = 2;
      scene.add(booksGroup);
    }

    function animate() {
      booksGroup.rotation.x -= 0.003;
      booksGroup.rotation.y -= 0.003;
      booksGroup.rotation.z -= 0.003;

      controls.update();
      requestAnimationFrame(animate);
      renderer.render(scene, camera);
    }

    init();

    return () => {
      window.removeEventListener("resize", onWindowResize);
      if (containerRef.current && renderer) {
        containerRef.current.removeChild(renderer.domElement);
        renderer.dispose();
      }
    };
  }, []);

  return (
    <div className="floating-books-container" ref={containerRef}>
      <div className="floating-books-overlay-text">
        <span className="floating-books-color-change">
          This is placeholder text for a brief overview of my writing. It will eventually describe the focus, tone, and themes of my work.
        </span>
      </div>
    </div>
  );
};

export default FloatingBooks;
