import React, { useEffect, useRef } from "react";
import "./Goal.css";

const IMAGES = [
  "/images/goal/7.png",
  "/images/goal/7.png",
  "/images/goal/7.png",
  "/images/goal/7.png",
  "/images/goal/7.png",
  "/images/goal/7.png",
];

export default function Carousel() {
  const stackRef = useRef(null);

  useEffect(() => {
    const stack = stackRef.current;
    let lastTime = performance.now();

    const moveCard = () => {
      const lastCard = stack.lastElementChild;
      if (lastCard && lastCard.classList.contains("goal-card")) {
        lastCard.classList.add("goal-swap");
        setTimeout(() => {
          lastCard.classList.remove("goal-swap");
          stack.insertBefore(lastCard, stack.firstElementChild);
        }, 1200);
      }
    };

    const loop = (time) => {
      if (time - lastTime > 4000) {
        moveCard();
        lastTime = time;
      }
      requestAnimationFrame(loop);
    };

    requestAnimationFrame(loop);
  }, []);

  const handleClick = (e) => {
    const stack = stackRef.current;
    const card = e.target.closest(".goal-card");
    if (card && card === stack.lastElementChild) {
      card.classList.add("goal-swap");
      setTimeout(() => {
        card.classList.remove("goal-swap");
        stack.insertBefore(card, stack.firstElementChild);
      }, 1200);
    }
  };

  return (
    <section className="goal-section">
      <div className="goal-content">
        <h1>Our Goal At RVGo</h1>
        <p>
          At RV Go, our goal is simple: to make learning accessible, effective,
          and affordable, while ensuring each student reaches their highest
          potential. With a combination of personalized tutoring and a proven
          test prep strategy, RV Go is the perfect partner for students aiming
          for success in their standardized exams.
        </p>
        <button className="goal-btn">Explore Our Courses</button>
      </div>

      <div className="goal-stack" ref={stackRef} onClick={handleClick}>
        {IMAGES.map((src, i) => (
          <div className="goal-card" key={i}>
            <img src={src} alt={`Goal ${i + 1}`} loading="lazy" />
          </div>
        ))}
      </div>
    </section>
  );
}
