"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import Lenis from "@studio-freight/lenis";
import React, { useRef, useEffect } from "react";
import "./Skiper.css";

const projects = [
  { title: "Project 1", description: "This is the first project." },
  { title: "Project 2", description: "Details about the second project." },
  { title: "Project 3", description: "Some information about project three." },
  { title: "Project 4", description: "Fourth project description goes here." },
  { title: "Project 5", description: "Fifth project overview and summary." },
];

const StickyCard = ({ i, title, description, progress, range, targetScale }) => {
  const container = useRef(null);

  const scale = useTransform(progress, range, [1, targetScale]);
  const opacity = useTransform(progress, range, [1, 0.3]);

  return (
    <div ref={container} className="sticky-card-container">
      <motion.div
        style={{
          scale,
          opacity,
          top: `calc(${i * 15}vh)`,
        }}
        className={`sticky-card sticky-card-${i}`}
      >
        <h2 className="sticky-card-title">{title}</h2>
        <p className="sticky-card-description">{description}</p>
      </motion.div>
    </div>
  );
};

const Skiper = () => {
  const container = useRef(null);
  const { scrollYProgress } = useScroll({
    target: container,
    offset: ["start start", "end end"],
  });

  useEffect(() => {
    const lenis = new Lenis({
      smooth: true,
      lerp: 0.1,
    });

    function raf(time) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);

    return () => {
      lenis.destroy();
    };
  }, []);

  return (
    <main ref={container} className="skiper-main">
      <div className="skiper-header">
        <span className="skiper-subtitle">scroll down to see card stack</span>
      </div>
      {projects.map((project, i) => {
        const targetScale = Math.max(0.5, 1 - (projects.length - i - 1) * 0.1);
        return (
          <StickyCard
            key={`p_${i}`}
            i={i}
            {...project}
            progress={scrollYProgress}
            range={[i * (1 / projects.length), 1]}
            targetScale={targetScale}
          />
        );
      })}
    </main>
  );
};

export default Skiper;
