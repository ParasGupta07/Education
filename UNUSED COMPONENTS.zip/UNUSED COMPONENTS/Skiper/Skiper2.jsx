"use client";

import { motion } from "framer-motion";
import { ChevronLeftIcon, ChevronRightIcon } from "lucide-react";
import React from "react";
import { Autoplay, EffectCards, Navigation, Pagination } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css/effect-cards";
import "swiper/css/pagination";
import "swiper/css/navigation";
import "swiper/css";

import "./Skiper2.css";

const Skiper2 = () => {
  const images = [
    { src: "/images/goal/2.jpg", alt: "Illustrations by AarzooAly" },
    { src: "/images/goal/2.jpg", alt: "Illustrations by AarzooAly" },
    { src: "/images/goal/2.jpg", alt: "Illustrations by AarzooAly" },
    { src: "/images/goal/2.jpg", alt: "Illustrations by AarzooAly" },
    { src: "/images/goal/2.jpg", alt: "Illustrations by AarzooAly" },
    { src: "/images/goal/2.jpg", alt: "Illustrations by AarzooAly" },
    { src: "/images/goal/2.jpg", alt: "Illustrations by AarzooAly" },
    { src: "/images/goal/2.jpg", alt: "Illustrations by AarzooAly" },
    { src: "/images/goal/2.jpg", alt: "Illustrations by AarzooAly" },
    { src: "/images/goal/2.jpg", alt: "Illustrations by AarzooAly" },
    { src: "/images/goal/2.jpg", alt: "Illustrations by AarzooAly" },
  ];

  return (
    <div className="skiper2-wrapper">
      {/* Autoplay disabled by default */}
      <Carousel2 images={images} loop autoplay={false} showPagination={false} />
    </div>
  );
};

export default Skiper2;

const Carousel2 = ({
  images,
  showPagination = false,
  showNavigation = false,
  loop = true,
  autoplay = false, // default = false so it won’t swipe automatically
  spaceBetween = 40,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, translateY: 20 }}
      animate={{ opacity: 1, translateY: 0 }}
      transition={{ duration: 0.3, delay: 0.5 }}
      className="carousel2-container"
    >
      <Swiper
        spaceBetween={spaceBetween}
        autoplay={
          autoplay
            ? {
                delay: 3000, // only autoplay if explicitly enabled
                disableOnInteraction: true,
                pauseOnMouseEnter: true,
              }
            : false
        }
        effect="cards"
        grabCursor={true}
        loop={loop}
        pagination={showPagination ? { clickable: true } : false}
        navigation={
          showNavigation
            ? { nextEl: ".swiper-button-next", prevEl: ".swiper-button-prev" }
            : false
        }
        className="carousel2-swiper"
        modules={[EffectCards, Autoplay, Pagination, Navigation]}
      >
        {images.map((image, index) => (
          <SwiperSlide key={index} className="carousel2-slide">
            <img
              className="carousel2-image"
              src={image.src}
              alt={image.alt}
              loading="lazy"
            />
          </SwiperSlide>
        ))}

        {showNavigation && (
          <div>
            <div className="swiper-button-next after:hidden">
              <ChevronRightIcon className="carousel2-nav-icon" />
            </div>
            <div className="swiper-button-prev after:hidden">
              <ChevronLeftIcon className="carousel2-nav-icon" />
            </div>
          </div>
        )}
      </Swiper>
    </motion.div>
  );
};
