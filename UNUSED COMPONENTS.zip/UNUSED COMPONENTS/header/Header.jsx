import { useState, useEffect, useRef } from "react";
import "./Header.css";
import logo from "../../favicon.png";

const Header = () => {
  const [showSignIn, setShowSignIn] = useState(false);
  const [isActiveInside, setIsActiveInside] = useState(false);
  const dropdownRef = useRef(null);
  const idleTimer = useRef(null);

  // Auto-close after 4s idle
  useEffect(() => {
    if (showSignIn && !isActiveInside) {
      idleTimer.current = setTimeout(() => {
        setShowSignIn(false);
      }, 4000);
    }
    return () => clearTimeout(idleTimer.current);
  }, [showSignIn, isActiveInside]);

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setShowSignIn(false);
      }
    };
    if (showSignIn) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showSignIn]);

  return (
    <header className="header">
      {/* Top Section */}
      <div className="header-top">
        <div className="logo-container">
          <img src={logo} alt="Logo" className="site-logo" />
        </div>
        <nav className="header-nav">
          <ul>
            <li className="nav-item" ref={dropdownRef}>
              <button
                className="nav-link"
                onClick={() => setShowSignIn((prev) => !prev)}
              >
                <i className="icon fa-solid fa-arrow-right-to-bracket"></i>
                Sign In / Register
              </button>

              {showSignIn && (
                <div
                  className="sign-in-dropdown"
                  onMouseEnter={() => setIsActiveInside(true)}
                  onMouseLeave={() => setIsActiveInside(false)}
                >
                  <div className="sign-in-header">
                    <h4 className="sign-in-option">Sign In</h4>
                    <h4 className="sign-in-option create-account">
                      Create an Account
                    </h4>
                  </div>
                  <hr />
                  <div className="form-group">
                    <label>
                      Username or email <span>*</span>
                    </label>
                    <input type="text" placeholder="Username" />
                  </div>
                  <div className="form-group">
                    <label>
                      Password <span>*</span>
                    </label>
                    <input type="password" placeholder="Password" />
                  </div>
                  <button className="login-btn">Login</button>
                  <p className="forgot-password">Lost your password?</p>
                </div>
              )}
            </li>

            <li className="nav-item">
              <a href="#about" className="nav-link">
                <i className="icon fas fa-info-circle"></i> About RVGo
              </a>
            </li>
          </ul>
        </nav>
      </div>

      {/* Bottom Section */}
      <div className="header-bottom">
        <nav className="main-menu">
          <ul>
            <li className="menu-item">
              <a href="#home" className="menu-link">
                <span className="menu-text">HOME</span>
              </a>
            </li>
            <li className="menu-item">
              <a href="#about-us" className="menu-link">
                <span className="menu-text">ABOUT US</span>
              </a>
            </li>
            <li className="menu-item">
              <a href="#why-choose-us" className="menu-link">
                <span className="menu-text">WHY CHOOSE US?</span>
              </a>
            </li>
            <li className="menu-item">
              <a href="#testimonials" className="menu-link">
                <span className="menu-text">TESTIMONIALS</span>
              </a>
            </li>
            <li className="menu-item">
              <a href="#contact" className="menu-link">
                <span className="menu-text">CONTACT</span>
              </a>
            </li>
          </ul>
        </nav>

        <div className="search-box">
          <input
            type="text"
            className="search-input"
            placeholder="Search.."
          />
        </div>
      </div>
    </header>
  );
};

export default Header;
