import React, { useState } from 'react';
import Slider from 'react-slick';
import './SliderComponent.css';
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";

const SliderComponent = () => {
    const [activeSlide, setActiveSlide] = useState(0);

    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 7000,
        arrows: true,
        prevArrow: <CustomPrevArrow />,
        nextArrow: <CustomNextArrow />,
        pauseOnHover: false,
        afterChange: (current) => setActiveSlide(current)
    };

    const slides = [
        {
            id: 1,
            image: '/images/slider/slider1.png',
            className: 'slide-1',
            content: 'Study. Learn. Grow.'
        },
        {
            id: 2,
            image: '/images/slider/slider2.jpg',
            className: 'slide-2',
            heading: 'RVGO',
            subheading: 'Reach the Victory',
        },
        {
            id: 3,
            image: '/images/slider/slider3.png',
            className: 'slide-3',
            content: 'Learning never ends'
        }
    ];

    return (
        <div className="slider-container">
            <Slider {...settings}>
                {slides.map(slide => (
                    <div key={slide.id} className={`slide ${slide.className}`}>
                        <img src={slide.image} alt={`Slide ${slide.id}`} />
                        {slide.content && (
                            <div className="slide-content">
                                <AnimatedText content={slide.content} isActive={activeSlide === slide.id - 1} />
                                {slide.id === 1 && (
                                    <>
                                        <div className="additional-content">
                                            <div className='shine'>Education At Discount</div>
                                            <div><button className='slider-button'>CONTACT US</button></div>
                                        </div>
                                    </>
                                )}
                                {slide.id === 3 && (
                                    <>
                                        <div className="additional-content">
                                            <div className='shine shine-new'>Save On Courses</div>
                                        </div>
                                    </>
                                )}
                            </div>
                        )}
                        {slide.id === 2 && (
                            <div className={activeSlide === slide.id - 1 ? "animated-box active" : "animated-box"}>
                                <div className="box-content">
                                    <h2 className={activeSlide === slide.id - 1 ? 'delayed-text active' : 'delayed-text'}>{slide.heading}</h2>
                                    <p className={activeSlide === slide.id - 1 ? 'delayed-text active' : 'delayed-text'}>{slide.subheading}</p>
                                    <AnimatedText content={slide.content} isActive={activeSlide === slide.id - 1} />
                                </div>
                            </div>
                        )}
                    </div>
                ))}
            </Slider>
        </div>
    );
};

const AnimatedText = ({ content, isActive }) => (
    <p className={isActive ? 'text-effect active' : 'text-effect'}>
        <span className="text-wrapper">
            <span>{content}</span>
        </span>
    </p>
);

const CustomPrevArrow = ({ className, style, onClick }) => (
    <div
        className={className}
        style={{ ...style, display: 'block', color: 'white', left: '15px' }}
        onClick={onClick}
    >
        <i className="fa-solid fa-circle-chevron-left"></i>
    </div>
);

const CustomNextArrow = ({ className, style, onClick }) => (
    <div
        className={className}
        style={{ ...style, display: 'block', color: 'white', right: '15px' }}
        onClick={onClick}
    >
        <i className="fa-solid fa-circle-chevron-right"></i>
    </div>
);

export default SliderComponent;
