import React, { useEffect, useRef, useState } from "react";
import "./Slider2.css";

const SLIDES = [
  { 
    id: 1, 
    title: "Learning never ends", 
    desc: "Hurry! Enroll in our courses today and take advantage of exclusive learning discounts.", 
    bg: "#500033", 
    fg: "#FF0077",
    img: "/images/slider/slider10.png" 
  },
  { 
    id: 2, 
    title: "Knowledge Creates Freedom", 
    desc: "Grab this opportunity to gain knowledge, skills, and success at discounted prices now.", 
    bg: "#000050", 
    fg: "#0033FF",
    img: "/images/slider/slider6.png"
  },
  { 
    id: 3, 
    title: "Study Strengthens Character", 
    desc: "Learn smarter, grow faster, and save more with our specially priced courses today.", 
    bg: "#00501D", 
    fg: "#00FF44",
    img: "/images/slider/slider8.png"
  },
];

export default function Slider() {
  const [index, setIndex] = useState(0);
  const [entering, setEntering] = useState(false);

  const slidesCount = SLIDES.length;

  const AUTOPLAY_MS = 3800;
  const autoplayRef = useRef(null);
  const pausedRef = useRef(false);

  const startX = useRef(0);
  const deltaX = useRef(0);
  const pointerDown = useRef(false);

  useEffect(() => {
    startAutoplay();
    return stopAutoplay;
  }, []);

  useEffect(() => {
    setEntering(true);
    const t = setTimeout(() => setEntering(false), 900);
    return () => clearTimeout(t);
  }, [index]);

  function startAutoplay() {
    stopAutoplay();
    autoplayRef.current = setInterval(() => {
      if (!pausedRef.current) {
        setIndex((i) => (i === slidesCount - 1 ? 0 : i + 1));
      }
    }, AUTOPLAY_MS);
  }
  function stopAutoplay() {
    if (autoplayRef.current) {
      clearInterval(autoplayRef.current);
      autoplayRef.current = null;
    }
  }

  function goPrev() {
    setIndex((i) => (i === 0 ? slidesCount - 1 : i - 1));
  }
  function goNext() {
    setIndex((i) => (i === slidesCount - 1 ? 0 : i + 1));
  }
  function goTo(i) {
    setIndex(i);
  }

  function handleMouseEnter() {
    pausedRef.current = true;
  }
  function handleMouseLeave() {
    pausedRef.current = false;
  }

  function onPointerDown(e) {
    pointerDown.current = true;
    startX.current = (e.touches ? e.touches[0].clientX : e.clientX) ?? e.clientX;
    deltaX.current = 0;
  }
  function onPointerMove(e) {
    if (!pointerDown.current) return;
    const x = (e.touches ? e.touches[0].clientX : e.clientX) ?? e.clientX;
    deltaX.current = startX.current - x;
  }
  function onPointerUp() {
    if (!pointerDown.current) return;
    pointerDown.current = false;
    const threshold = 50;
    if (deltaX.current > threshold) {
      goNext();
    } else if (deltaX.current < -threshold) {
      goPrev();
    }
    deltaX.current = 0;
  }

  function handlePrevClick() {
    goPrev();
    startAutoplay();
  }
  function handleNextClick() {
    goNext();
    startAutoplay();
  }

  return (
    <div
      className="ns-slider"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <button
        className="ns-nav ns-prev"
        onClick={handlePrevClick}
        aria-label="Previous slide"
      >
        <svg viewBox="0 0 56.898 91" width="36" height="58"><path d="M45.5,0,91,56.9,48.452,24.068,0,56.9Z" transform="translate(0 91) rotate(-90)" fill="currentColor"/></svg>
      </button>

      <button
        className="ns-nav ns-next"
        onClick={handleNextClick}
        aria-label="Next slide"
      >
        <svg viewBox="0 0 56.898 91" width="36" height="58"><path d="M45.5,0,91,56.9,48.452,24.068,0,56.9Z" transform="translate(56.898) rotate(90)" fill="currentColor"/></svg>
      </button>

      <div
        className="ns-viewport"
        onMouseDown={onPointerDown}
        onMouseMove={onPointerMove}
        onMouseUp={onPointerUp}
        onTouchStart={onPointerDown}
        onTouchMove={onPointerMove}
        onTouchEnd={onPointerUp}
      >
        <div
          className="ns-track"
          style={{
            width: `${slidesCount * 100}%`,
            transform: `translateX(-${(index * 100) / slidesCount}%)`,
          }}
        >
          {SLIDES.map((s, i) => {
            const isActive = i === index;
            return (
              <section
                key={s.id}
                className={`ns-slide ${isActive ? "active" : ""} ${isActive && entering ? "entering" : ""}`}
                style={{ backgroundColor: s.bg, width: `${100 / slidesCount}%` }}
              >
                <div className="ns-bg" aria-hidden />
                <div className="ns-details">
                  <h1 className="ns-title">{s.title}</h1>
                  <p className="ns-desc">{s.desc}</p>
                  <button
                    className="ns-cta"
                    style={{ backgroundColor: s.fg }}
                    aria-label={`Check ${s.title}`}
                  >
                    Contact Us
                  </button>
                </div>

                <div className="ns-illustration" aria-hidden>
                  {s.img && <img src={s.img} alt={s.title} className="ns-image" />}
                </div>
              </section>
            );
          })}
        </div>
      </div>

      <div className="ns-trail">
        {SLIDES.map((_, i) => (
          <button
            key={i}
            className={`ns-trail-item ${i === index ? "active" : ""}`}
            onClick={() => { goTo(i); startAutoplay(); }}
            aria-label={`Go to slide ${i + 1}`}
          >
            <span className="ns-trail-line" />
            <span className="ns-trail-num">{i + 1}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
